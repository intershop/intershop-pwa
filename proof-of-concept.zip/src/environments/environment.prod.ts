export const environment = {
  production: true,
  needMock: false
};
