import {Component} from  '@angular/core'

@Component({
    templateUrl:`./compareDetails.component.html`
})

export class CompareDetailsComponent{ 
    
}