import { Component } from '@angular/core';
// /import { tileComponent } from '../tile/tile-component';

@Component({
    selector: 'is-header',
    templateUrl: './header.component.html',
    styles:
    ['.head {border-style: solid;border-color: black; border-width: 1px 1px 1px 1px; padding:50px 10px;text-align:center}' ]
})

export class HeaderSlotComponent {
    categories: any = [
        
        {
            name : 'Cameras'
        },
        {
            name : 'Computers'
        },
        {
            name : 'Home Entertainment'
        },
        {
            name : 'Specials'
        }

    ]
}
