import { Component } from '@angular/core';

@Component({
    selector: 'is-marketingslot',
    templateUrl: './marketing-slot.component.html'
})

export class MarketingSlotComponent {

}
