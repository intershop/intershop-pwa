import { Component } from '@angular/core';

@Component({
    selector: 'is-filterpanel',
    templateUrl: './category.component.html'
})

export class CategoryComponent {
}
