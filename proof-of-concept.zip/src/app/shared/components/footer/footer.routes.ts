import {FooterComponent} from './footer.component'

export const footerRoutes = [
   
]
