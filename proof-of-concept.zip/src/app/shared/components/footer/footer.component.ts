import { Component } from '@angular/core';

@Component({
    selector: 'is-footer',
    templateUrl: './footer.component.html',
    styles:
    ['.footer {border : solid black 1px; padding:15px 0;text-align:center; background: grey;color: white;}' ]
})

export class FooterComponent {

}
