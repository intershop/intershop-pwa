export interface ICompressDecompressService{
    
}