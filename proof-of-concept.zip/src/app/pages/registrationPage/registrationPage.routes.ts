
import { RegistrationPageComponent } from 'app/pages/registrationPage/registrationPage.component';

export const registrationPageRoute = [
     {path : '', component  : RegistrationPageComponent},
]
