
import { TilePageComponent } from "app/pages/tilePage/tilePage.component";

export const pageRoute = [
    {path : '', component  : TilePageComponent},
]
