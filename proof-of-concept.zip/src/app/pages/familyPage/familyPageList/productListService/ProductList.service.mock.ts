import { Injectable } from '@angular/core'
import { Observable } from 'rxjs/Rx'
import { IProductListService } from "app/pages/familyPage/familyPageList/productListService/iProductList.service";

@Injectable()
export class ProductListMockService implements IProductListService {

    ProductList = [
        {
            Cameras: [
                {
                    'id': 1,
                    'name': 'Dicota',
                    'range': 'Widespread resident across the country and up to 1600m in the hills',
                    'src': '../../assets/a.jpg',
                    'Brand': 'Dicota',
                    'Price': 5,
                    'color': 'red'
                },
                {
                    'id': 12,
                    'name': 'Dicota',
                    'range': 'Widespread resident. Absent from the dry west.',
                    'src': '../../assets/b.jpg',
                    'Brand': 'Dicota',
                    'Price': 9,
                    'color': 'red'
                },
                {
                    'id': 3,
                    'name': 'Fujifilm',
                    'range': 'Widespread resident across the country and up to 2500m in the hills.',
                    'src': '../../assets/c.jpg',
                    'Brand': 'Fujifilm',
                    'Price': 30,
                    'color': 'green'
                },
                {
                    'id': 4,
                    'name': 'Sony ',
                    'range': 'Widespread resident replaced by the Eurasian Tree Sparrow in the hills and in the extreme north-east.',
                    'src': '../../assets/d.jpg',
                    'Brand': 'Sony',
                    'Price': 31,
                    'color': 'black'
                }
            ],
        }
    ];

    getProductList(): Observable<any> {
        return Observable.of(this.ProductList);
    }

}


