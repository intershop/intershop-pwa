
import { FamilyPageComponent } from "app/pages/familyPage/familyPage.component";

export const familyPageRoute = [
     {path : '', component  : FamilyPageComponent},
]
