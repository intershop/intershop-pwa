import { Component, OnInit } from '@angular/core';

@Component({
  templateUrl: './error-page.component.html'
})
export class ErrorPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
