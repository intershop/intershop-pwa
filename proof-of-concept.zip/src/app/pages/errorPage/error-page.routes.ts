import { ErrorPageComponent } from './error-page.component'

export const errorPageRoute = [
    { path: '', component: ErrorPageComponent }
]
