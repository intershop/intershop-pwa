
import { TilePageComponent } from "app/pages/tilePage/tilePage.component";

export const tilePageRoute = [
     {path : '', component  : TilePageComponent},
]
