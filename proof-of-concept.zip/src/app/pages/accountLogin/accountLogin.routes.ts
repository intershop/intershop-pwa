
import { AccountLoginComponent } from "./accountLogin.component";

export const AccountLoginRoute = [
    { path: '', component: AccountLoginComponent }
]
